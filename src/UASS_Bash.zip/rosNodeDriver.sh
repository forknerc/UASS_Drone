# rosNodeDriver.sh
# starts UASS ros nodes

./pubDriver.sh &

./subDriver.sh $1 &

echo "DONE!"

