# UASS_Drone.sh
# Used an instance of a UASS drone system

echo "Starting ardrone driver"

# start ardrone driver
./ardroneDriver.sh &

# wait
sleep 12

echo "Starting tum ardrone"

# start tum ardrone
./tumDriver.sh &

# wait
sleep 10

echo "starting UASS ros nodes"

# start ros nodes
./rosNodeDriver.sh $1


