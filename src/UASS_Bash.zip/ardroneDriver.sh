# ardroneDriver.sh
# starts TUM ardrone driver

roslaunch tum_ardrone ardrone_driver.launch
