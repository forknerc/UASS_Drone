# runs UASS publisher

rosrun UASS pub
