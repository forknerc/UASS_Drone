# Runs UASS subscriber node

rosrun UASS sub $1
