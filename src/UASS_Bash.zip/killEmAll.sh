#pkill -9 ardrone_driver
#pkill -9 drone_autopilot
#pkill -9 drone_gui
kill $(ps aux | grep 'ardrone_driver' | awk '{print $2}')
kill $(ps aux | grep 'drone_autopilot' | awk '{print $2}')
kill $(ps aux | grep 'drone_gui' | awk '{print $2}')
kill $(ps aux | grep 'drone_stateestimation' | awk '{print $2}')
pkill -9 pub
pkill -9 sub
killall -9 roslaunch
echo "Programs are kill"
