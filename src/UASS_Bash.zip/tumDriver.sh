# tumDriver.sh
# starts TUM ardrone stuff

roslaunch tum_ardrone tum_ardrone.launch
